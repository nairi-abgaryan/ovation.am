<?php
/**
 * System Events Dutch lexicon topic
 *
 * @language nl
 * @package modx
 * @subpackage lexicon
 * 
 * @author Bert Oost, <bertoost85@gmail.com>
 */
$_lang['clear'] = 'Legen';
$_lang['error_log'] = 'Fout Log';
$_lang['error_log_desc'] = 'Hier is de fout log van MODX Revolution:';
$_lang['system_events'] = 'Systeem gebeurtenissen';
$_lang['priority'] = 'Prioriteit';